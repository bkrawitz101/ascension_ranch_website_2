#!/usr/bin/env bash
set -euo pipefail

# Creates a timestamped tar.gz of the project in the backups/ folder.
# Usage: ./scripts/backup.sh [--full]

TIMESTAMP=$(date +"%Y%m%d-%H%M%S")
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
BACKUP_DIR="$ROOT_DIR/backups"
FULL=false

for arg in "$@"; do
  case "$arg" in
    --full) FULL=true ;;
    -h|--help)
      echo "Usage: $0 [--full]"
      echo "  --full   include node_modules and other generated folders"
      exit 0 ;;
  esac
done

mkdir -p "$BACKUP_DIR"
FNAME="site-backup-$TIMESTAMP.tar.gz"

cd "$ROOT_DIR"
if [ "$FULL" = true ]; then
  tar czf "$BACKUP_DIR/$FNAME" \
    --exclude="./backups" \
    --exclude="./.git" \
    --exclude="./.DS_Store" \
    .
else
  tar czf "$BACKUP_DIR/$FNAME" \
    --exclude="./backups" \
    --exclude="./.git" \
    --exclude="./node_modules" \
    --exclude="./dist" \
    --exclude="./.DS_Store" \
    .
fi

echo "Created backup: $BACKUP_DIR/$FNAME"
